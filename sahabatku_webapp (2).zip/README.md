# Sahabatku Delivery WebApp

Ini adalah aplikasi web sederhana untuk **Sahabatku Delivery** dengan 3 halaman utama:

- `index.html` → Halaman utama (pilih login Admin / Kurir)
- `admin.html` → Panel Admin (dashboard dengan 4 box grid, manajemen kurir, dll)
- `kurir.html` → Panel Kurir (daftar nota, lihat nota dengan foto, tombol simpan & bagikan)

## Fitur
- Desain modern, elegan, dan responsif (mobile friendly)
- Tata letak **box grid** yang rapi dan tidak dempet di HP
- Animasi hover & pop untuk efek modern
- Fitur **Lihat Nota** dengan tampilan foto nota + tombol **Simpan Foto** dan **Bagikan Teks**
- Integrasi share ke WhatsApp atau Web Share API

## Cara Deploy ke GitHub Pages

1. **Buat repository baru di GitHub**  
   Misalnya: `sahabatku-delivery`

2. **Upload file dari ZIP ini**  
   (index.html, admin.html, kurir.html, dan README.md)

3. **Aktifkan GitHub Pages**  
   - Buka tab **Settings → Pages**  
   - Pilih branch `main` (atau `master`) dan folder root (`/`)  
   - Klik Save

4. **Akses aplikasi**  
   Buka di browser:  
   ```
   https://username.github.io/sahabatku-delivery/
   ```

## Catatan
- Anda bisa menambahkan asset (gambar, CSS eksternal, JS tambahan) di folder terpisah bila diperlukan.
- Jika ingin menambahkan Firebase atau database, hubungkan di dalam file `admin.html` atau `kurir.html`.

---
Dibuat dengan ❤️ untuk Sahabatku Delivery
